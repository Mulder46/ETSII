
public class Titulo implements Comparable{
	private String cadena;
	private String segunda;
	
	public String 
	
	
	
}
