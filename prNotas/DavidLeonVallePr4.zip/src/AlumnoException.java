
public class AlumnoException  extends Exception{
	public AlumnoException(String error){
		super(error);
	}
}
