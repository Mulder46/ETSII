
public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Carta c=new Carta(12,Carta.Palo.Diamantes);
		System.out.print(c.toString());

	}

}
