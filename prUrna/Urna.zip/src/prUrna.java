
public class prUrna {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Urna caja=new Urna(10,10);
		if(totalBolas()>0){
			ColorBola color1=extraerBola();
			ColorBola color2=extraerBola();
			if(color1==color2){
				ponerBlanca();		
			}else{
			ponerNegra();
			}
		}
	}	
}
